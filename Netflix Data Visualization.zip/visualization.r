# Load necessary library
library(ggplot2)

# Load the dataset
df <- read.csv("C:/Users/akmusinguzi/Downloads/Netflix_shows_movies.csv")

# Replace missing values in the 'rating' column with 'Unknown'
df$rating[is.na(df$rating)] <- "Unknown"

# Create a bar plot for the rating distribution
ggplot(data = df, aes(x = rating)) +
  geom_bar(fill = 'skyblue', color = 'black') +
  labs(x = 'Rating', y = 'Frequency', title = 'Ratings Distribution') +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  theme_minimal()

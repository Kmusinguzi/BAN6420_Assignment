Flask Application, Data Visualizations, and Hosting on AWS
This README provides a guide for developing a Flask web application, performing data analysis and visualizations in Jupyter, and hosting the Flask app on Amazon Web Services (AWS). The app collects survey data, saves responses to a MongoDB database, allows exporting data to CSV, and visualizes the data for analysis and presentation.

1. Developing the Flask Application:
(i) Overview
This Flask app allows users to fill out a survey and saves their responses to a MongoDB database. It also provides an option to export the collected survey data to a  CSV file. Below is a breakdown of the core features:

(ii) Setup and Imports
 -Flask: The micro web framework for building the application.
 -MongoClient: To connect and interact with the MongoDB database.
 -logging: For logging important events and errors during execution.
 -csv, os: For exporting survey data to a CSV file.

(iii) Key Components
-Logging Configuration
  The application logs messages at the DEBUG level, helping to track application behavior and errors.

-MongoDB Connection
  The app connects to a local MongoDB instance (mongodb://localhost:27017/). If the connection is successful, it logs a success message; otherwise, it raises an error.

-Database Setup
  The app connects to a database named survey_db and a collection named responses, where the survey responses are stored.

-User Class
  The User class is defined with attributes such as age, gender, income, and expenses. The to_dict() method returns the data as a dictionary for insertion into MongoDB.

(iv) Survey Route (/)
-GET: Renders the survey form (e.g., survey_form.html).
-POST: Processes the form data and:
	Collects user's age, gender, and income.
	Collects expenses in various categories (e.g., utilities, entertainment).
	Creates a User object and saves the data in MongoDB.
	Redirects to a "Thank You" page or returns an error message.
	Thank You Route (/thank_you)
	After survey submission, users are redirected to a page displaying a "Thank You" message.

(v) Generating random responses
A script was generated that submits random survey responses to a Flask application. It simulates a survey submission process by generating random data for age, gender, income, and expenses in predefined categories and sending them to the Flask app using HTTP POST requests.

(vi) Export to CSV Route (/export)
Fetches all survey responses from MongoDB.
Writes the data to a CSV file with fields like age, gender, income, and expenses.
Saves the file as survey_data.csv in the working directory.


2. Data Analysis and Visualization in Jupyter:
This Python script analyzes and visualizes survey data stored in a CSV file. It uses pandas for data processing, matplotlib and seaborn for visualizations, and python-pptx to generate a PowerPoint presentation showcasing the results.

(i) Visualizations
# Top 10 Ages with the Highest Income
Bar Plot: Shows the relationship between age and income.
X-axis: Age
Y-axis: Income

# Gender Distribution Across Spending Categories
Stacked Bar Chart: Shows the distribution of spending across categories by gender.
X-axis: Gender
Y-axis: Total spending in categories like utilities, entertainment, etc.

(ii) PowerPoint Presentation
After creating the visualizations, they are saved as images and added to a PowerPoint presentation.
Slide 1: Displays the "Top 10 Ages with the Highest Income" chart.
Slide 2: Displays the "Gender Distribution Across Spending Categories" chart.

(iii) Requirements
To run this part of the project, you will need the following Python libraries:
-pandas: For data manipulation.
-matplotlib: For creating plots.
-seaborn: For statistical visualizations.
-python-pptx: For generating PowerPoint slides.

(iv) File Structure
-survey_data.csv: Survey responses stored in CSV format.
-top_ages_with_highest_income.png: Image of the bar plot for top 10 ages with highest income.
-gender_distribution_spending.png: Image of the stacked bar chart for gender distribution across spending categories.
-survey_data_visualizations.pptx: PowerPoint presentation containing the visualizations.

Running the Visualization Script
To generate the visualizations and PowerPoint presentation, run the following Python script: "python generate_visualizations.py"
This script will:
-Load the survey data from the CSV.
-Create the visualizations.
-Save the visualizations as image files.
-Generate a PowerPoint presentation with the charts.

The output will include:
-Images (top_ages_with_highest_income.png and gender_distribution_spending.png).
-PowerPoint presentation (survey_data_visualizations.pptx).


3. Hosting the Flask Application on AWS
(i) Launch an EC2 Instance
-Log in to the AWS Management Console and launch a Windows Server EC2 instance (e.g., Windows_Server-2025).
-Choose t3.micro (free tier eligible) and enable Auto-Assign Public IP.
-Add 30 GB of storage and configure the security group to allow:
-HTTP (port 80)
-Custom TCP (port 5000 for Flask app)
-RDP (port 3389 for remote access)
-Download and save the key pair for SSH access.

(ii) Connect to the Instance
-Open the Remote Desktop Connection tool on your computer.
-Use the .pem file to decrypt the default password for the instance in the AWS Console.
-Connect to the instance using its public IP and decrypted password.

(iii) Set Up the Windows Server
-Install Python from python.org, making sure to add Python to the PATH.
-Install required libraries using pip:"pip install flask pymongo
-Install MongoDB.

(iv) Deploy Your Flask Application
-Use the Remote Desktop Connection to copy your Flask app files to the server and place them in a directory (C:\Users\Administrator\project_app)
-Navigate to the directory where app.py is located:"C:\Users\Administrator\project_app"-
-Run the application: "python app.py"
-Test locally using "http://127.0.0.1:5000"

(v) Make the Flask App Public
-Modify app.run() in app.py to make the app accessible:"app.run(host='0.0.0.0', port=5000)"
-Restart the Flask app and access it via "http://13.60.40.146:5000".
By default, Flask will run in a development server, which stops when the session (like your SSH or remote desktop session) is closed
Using command "start /B python app.py will run the Flask app in the background, and the command prompt window will return to the prompt, allowing you to continue working.

(vi) Export CSV File
-Access /export: Visit "http://13.60.40.146:5000/export" in your browser.
-A file survey_data.csv will be saved to the directory where the app is running.(Data exported to C:\Users\Administrator\project_app\survey_data.csv)
-Copy the survey_data.csv file to your local machine.
import requests
import random

# URL of your Flask app
url = "http://127.0.0.1:5000"

# Define sample data for random generation
genders = ["Male", "Female"]
expense_categories = ["utilities", "entertainment", "school_fees", "shopping", "healthcare"]

def generate_random_response():
    """Generate a random survey response."""
    return {
        "age": str(random.randint(25, 65)),  # Random age between 18 and 65
        "gender": random.choice(genders),
        "income": str(random.randint(30000, 100000)),  # Random income
        **{category: str(random.randint(100, 1000)) for category in expense_categories}
    }

def submit_response(data):
    """Submit a single response."""
    try:
        response = requests.post(url, data=data, allow_redirects=True)
        if response.status_code == 200:  # Even after redirect, Flask responds with 200
            print(f"Response submitted successfully: {data}")
        else:
            print(f"Failed to submit response: {data} | Status Code: {response.status_code}")
    except Exception as e:
        print(f"Error submitting response: {e}")

# Generate and submit 100 responses
for i in range(100):
    print(f"Submitting response {i + 1}...")
    response_data = generate_random_response()
    submit_response(response_data)
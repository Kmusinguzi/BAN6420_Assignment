from flask import Flask, render_template, request, redirect, url_for
from pymongo import MongoClient
import logging
import csv
import os

# Configure logging
logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)

# Connect to MongoDB
try:
    client = MongoClient("mongodb://localhost:27017/")
    client.admin.command('ping')  # Test the MongoDB connection
    logging.info("Successfully connected to MongoDB.")
except Exception as e:
    logging.error(f"Failed to connect to MongoDB: {e}")
    raise

# Database and collection setup
db = client["survey_db"]
collection = db["responses"]

# Define the User class
class User:
    def __init__(self, age, gender, income, expenses):
        self.age = age
        self.gender = gender
        self.income = income
        self.expenses = expenses

    def to_dict(self):
        return {
            "age": self.age,
            "gender": self.gender,
            "income": self.income,
            **self.expenses
        }

@app.route('/', methods=['GET', 'POST'])
def survey():
    if request.method == 'POST':
        try:
            # Collect user data with form validation
            age = request.form.get('age')
            gender = request.form.get('gender')
            income = request.form.get('income')

            if not all([age, gender, income]):
                return "Please fill all required fields."

            # Collect expenses
            expense_categories = ['utilities', 'entertainment', 'school_fees', 'shopping', 'healthcare']
            expenses = {category: request.form.get(category, '') for category in expense_categories}

            # Create a User instance
            user = User(age, gender, income, expenses)

            # Store data in MongoDB
            collection.insert_one(user.to_dict())

            logging.info("Survey response successfully saved to MongoDB.")
            return redirect(url_for('thank_you'))
        except Exception as e:
            logging.error(f"An error occurred while processing the survey: {e}")
            return "An error occurred while processing your response. Please try again."

    return render_template("survey_form.html")

@app.route('/thank_you')
def thank_you():
    return "<h1>Thank you for your response! Your data has been recorded.</h1>"

@app.route('/export')
def export_to_csv():
    try:
        # Fetch data from MongoDB
        logging.debug("Fetching survey data from MongoDB...")
        users = list(collection.find({}, {'_id': 0}))

        # If no data is available
        if not users:
            logging.warning("No survey data available for export.")
            return "No survey data available for export."

        # Define CSV file path
        file_path = os.path.join(os.getcwd(), 'survey_data.csv')
        logging.debug(f"CSV file will be created at: {file_path}")

        # Export to CSV
        keys = ['age', 'gender', 'income', 'utilities', 'entertainment', 'school_fees', 'shopping', 'healthcare']
        with open(file_path, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=keys)
            writer.writeheader()
            logging.debug("CSV headers written.")
            for user in users:
                logging.debug(f"Writing user data to CSV: {user}")
                writer.writerow(user)

        logging.info(f"Data successfully exported to {file_path}")
        return f"Data exported to {file_path}"

    except Exception as e:
        logging.error(f"Error exporting data to CSV: {e}")
        return "An error occurred while exporting data. Please try again."

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000)
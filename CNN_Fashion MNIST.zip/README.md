This assignment demonstrates the process of classifying images from the Fashion MNIST dataset using a Convolutional Neural Network (CNN) built with TensorFlow and Keras. The Fashion MNIST dataset consists of 60,000 28x28 grayscale images in 10 categories, and the goal is to build a model that can accurately classify these images into one of those categories.

Prerequisites
Ensure that you have the following libraries installed:
  (i)tensorflow: For building and training the deep learning model.
  (ii)numpy: For numerical operations.
  (iii)matplotlib: For visualizing images.
	
Overview
1. Import Libraries
The necessary libraries TensorFlow for building the CNN, numpy for handling arrays, and matplotlib for displaying images are imported. 
In addition, 
tensorflow.keras: A high-level API for building and training deep learning models. It provides the Sequential class to create a model and layers for adding layers to the model. 
fashion_mnist: A module in tensorflow.keras.datasets that allows you to easily load the Fashion MNIST dataset.

2. Load the Fashion MNIST Dataset
The Fashion MNIST dataset is loaded using TensorFlow's fashion_mnist.load_data(). This dataset is divided into two sets:
  (i)Training Set: 60,000 images used to train the model.
  (ii) Test Set: 10,000 images used to evaluate the model's performance.

3. Preprocess the Data
  (i) Normalization: The pixel values of the images are scaled from a range of 0-255 to 0-1.
  (ii) Reshaping: The images are reshaped to add a channel dimension, as the CNN expects a 4D input (batch_size, height, width, channels). In this case, we have grayscale images, so only one channel is used.

4. Build the CNN Model
The CNN is created using TensorFlow's Keras API with the following layers:
  (i) Input Layer: Takes images of shape (28, 28, 1).
  (ii) Convolutional Layers: Three Conv2D layers with 32, 64, and 64 filters of size (3, 3), respectively, followed by MaxPooling2D layers for downsampling.
  (iii) Flatten Layer: Converts the 2D feature maps into a 1D vector.
  (iv) Dense Layers: Includes a fully connected layer with 64 neurons, a dropout layer to prevent overfitting, and a final output layer with 10 neurons (one for each class) using the softmax activation function.

5. Compile the Model
The model is compiled using:
  (i) Optimizer: Adam optimizer for efficient training.
  (ii) Loss Function: Sparse Categorical Crossentropy, suitable for multiclass classification.
  (iii) Metrics: Accuracy is used to evaluate the model performance.

6. Train the Model
The model is trained for 12 epochs with a batch size of 64 using the fit() function. During training, the model learns to classify images based on the patterns in the pixel values.

7. Evaluate the Model
After training, the model is evaluated on the test set to check its accuracy using evaluate().

8. Make Predictions
The trained model is used to make predictions on the first two images from the test set, and the predicted labels are displayed.

9. Visualize Predictions
The images and their predicted labels are shown using matplotlib. The predicted label is displayed as the title of each image.
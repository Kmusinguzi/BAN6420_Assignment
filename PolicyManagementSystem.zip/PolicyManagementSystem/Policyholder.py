class Policyholder:
    def __init__(self, policyholder_id, name, status="Active"):
        self.policyholder_id = policyholder_id
        self.name = name
        self.status = status

    def register(self):
        self.status = "Active"
        print(f"Policyholder {self.name} (ID: {self.policyholder_id} has been registered)")

    def suspend(self):
        self.status = "Suspended"
        print(f"Policyholder {self.name} ID: {self.policyholder_id} has been suspended")

    def reactivate(self):
        self.status = "Active"
        print(f"Policyholder {self.name} (ID: {self.policyholder_id} has been reactivated)")
        
    def display_details(self):
        return f"ID: {self.policyholder_id}, name: {self.name}, status: {self.status}"


class Products:
    def __init__(self, product_code, type, price, status="Created"):
        self.product_code = product_code
        self.type = type
        self.price = price
        self.status = status

    def create_product(self):
        self.status = "Created"
        print(f"Product {self.type} (Code: {self.product_code}) has been created")

    def update_product(self, type=None, price=None):
        self.status = "Updated"
        if type:
            self.type = type
        if price:
            self.price = price
        print(f"Product {self.type} (Code: {self.product_code} has been updated)")
    
    def suspend_product(self):
        self.status = "Suspended"
        print(f"Product {self.type} (Code = {self.product_code} has been suspended)")

    def display_product(self):
        return f"Code: {self.product_code}, Type: {self.type}, Price: {self.price}, Status: {self.status}"

import Policyholder
import Products
import Payment

# Create policyholders
policyholder1 = Policyholder.Policyholder("PH001", "Shiloh")
policyholder2 = Policyholder.Policyholder("PH002", "Arielle")
policyholder3 = Policyholder.Policyholder("PH003", "Zuri")

# Create products
product1 = Products.Products("P101", "Health Insurance", 3000)
product2 = Products.Products("P102", "Motor Insurance", 8000)
product3 = Products.Products("P103", "Home Insurance", 10000)

# Create payments 
payment1 = Payment.Payment("PT201", policyholder1.policyholder_id, product1.product_code, product1.price)
payment2 = Payment.Payment("PT202", policyholder2.policyholder_id, product2.product_code, product2.price)
payment3 = Payment.Payment("PT203", policyholder3.policyholder_id, product3.product_code, product3.price)

# Display detailed account information with associated product and payment
def display_account_details(policyholder, product, payment):
    print(policyholder.display_details())
    print(product.display_product())
    print(f"Payment Status: {payment.status}")
    print("\n")

display_account_details(policyholder1, product1, payment1)
display_account_details(policyholder2, product2, payment2)
display_account_details(policyholder3, product3, payment3)
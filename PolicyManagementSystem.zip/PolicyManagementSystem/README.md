Insurance Management System
This system features management of policyholders, products, and payments. The system allows for the creation, updating, and suspension of policyholders and products, as well as processing and managing payments.

Files Overview:
(i) policyholder.py – Manages policyholder information and their status.
(ii) products.py – Handles creation of insurance products and status updates.
(iii) payment.py – Manages payment processing, reminders and penalties.
(iv) main.py – Combines the above classes to display account details for each policy holder.

(i) policyholder.py
	Class: Policyholder
	This class represents an insurance policyholder. It allows for managing their ID, name, and status.

	Methods:
	__init__(self, policyholder_id, name, status="Active"): Initializes a new policyholder with a given ID, name, and status (default: "Active").
	register(self): Registers the policyholder and sets their status to "Active".
	rsuspend(self): Suspends the policyholder by setting their status to "Suspended".
	reactivate(self): Reactivates the policyholder by setting their status to "Active".
	display_details(self): Returns the details of the policyholder including their ID, name, and status.

(ii) products.py
	Class: Products
	This class represents insurance products. It allows creating products, updating them, and changing their statuses.

	Methods:
	__init__(self, product_code, type, price, status="Created"): Initializes a new product with a given product code, type, price, and status (default: "Created").
	create_product(self): Creates a product and sets its status to "Created".
	update_product(self, type=None, price=None): Updates the product details and sets its status to "Updated".
	suspend_product(self): Suspends the product by setting its status to "Suspended".
	display_product(self): Returns the details of the product, including product code, type, price, and status.

(iii) payment.py
	Class: Payment
	This class manages the payments related to insurance products. It allows processing payments, sending reminders, and charging penalties for pending payments.

	Methods:
	__init__(self, payment_reference, policyholder_id, product_code, amount, status="Processed"): Initializes a new payment with a reference, associated 	policyholder ID, product code, amount, and status (default: "Processed").
	process_payment(self): Marks the payment as "Completed" after processing it.
	send_reminders(self): Sends a reminder for a payment if it is still "Pending".
	charge_penalty(self): Charges a penalty for a pending payment.

(iv) main.py
	This file demonstrates the functionality of the system by creating instances of the Policyholder, Products, and Payment classes. It then displays account 	details, including the policyholder's status, product information, and payment status.

	Steps in main.py:
	Creating Policyholders: Three policyholders (Shiloh, Arielle, Zuri) are created with unique IDs.
	Creating Products: Three products are created (Health Insurance, Motor Insurance, Home Insurance).
	Creating Payments: Payments are created for each policyholder and product, associating them with payment references.
	Displaying Account Information: For each policyholder, product, and payment, their details are displayed, including status information.

Usage:
To run the system, simply execute main.py:

Requirements:
Python 3.x
No external libraries are required for this project.
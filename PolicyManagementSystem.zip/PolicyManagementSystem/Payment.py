class Payment:
    def __init__(self, payment_reference, policyholder_id, product_code, amount, status="Completed"):
        self.payment_reference = payment_reference
        self.policyholder_id = policyholder_id
        self.product_code = product_code
        self.amount = amount
        self.status = status
    
    def process_payment(self):
        self.status = "Completed"
        print(f"Payment {self.payment_reference} has been processed")

    def send_reminders(self):
        if self.status == "Pending":
            print(f"Reminder: Payment {self.payment_reference} is still pending")

    def charge_penalty(self):
        if self.status == "Pending":
            print(f"Penalty has been charged to Payment {self.payment_reference}")



        
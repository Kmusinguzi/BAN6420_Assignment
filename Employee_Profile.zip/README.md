Using Jupyter Notebook, the Python script extracts, processes, and exports employee data from a .zip file containing a .csv. It enables you to search for employee details, clean up the data, and export individual employee profiles into separate CSV files. Additionally, it allows you to compress these files into a ZIP archive.

Table of Contents:
1. Overview
2. Setup Instructions
3. How to Use
4. Exporting Data
5. Unzipping Data Using R
6. Error Handling

1. Overview:
  This script does the following:
    (i) Extracts a ZIP file containing a CSV file.
    (ii) Processes employee data by cleaning and deduplicating names.
    (iii) Exports employee details to individual CSV files.
    (iv) Creates a ZIP archive of all the employee CSV files.

2. Setup Instructions:
  Install Python 3.x on your system and the following packages:
    (i) pandas
    (ii) zipfile
    (iii) os
  Ensure you have the following files in your working directory:
     (i) Total.csv.zip – the ZIP file containing the CSV.
     (ii) Employee Profile – the folder where individual employee CSVs will be stored.
     (iii) Employee_Profile.zip – the output ZIP file containing the exported employee CSVs.

3. How to Use:
     (i) Make sure the ZIP file (Total.csv.zip) is in the correct path.
     (ii) Run the Script: The script automatically unzips the CSV file, loads it into a pandas DataFrame, and cleans the data by removing duplicates and normalizing the employee names.
    (iii) Using code: export_employee_details("NATHANIEL FORD"), will search for employee named "NATHANIEL FORD".
 
4. Exporting Data:
    (i) The script will export the employee details to a CSV file within the Employee Profile folder. This is done using the export_employee_details function. 
    (ii) Create a ZIP archive of the folder. After running the script, the following will be created:
      - A CSV file named NATHANIEL FORD.csv containing the employee’s data.
      - A ZIP file (Employee_Profile.zip) containing all employee CSV files.

5. Unzipping Data Using R:
    (i) Use the unzip() function to extract the contents of the ZIP file.
    (ii) Copy code specifying the ZIP file path
    (iii) After unzipping, load the CSV file into R using read.csv()

6. Error Handling:
  The script is designed to handle common errors gracefully:
    (i) Employee Not Found: If an employee name is not found in the dataset, an error message is shown.
   (ii) Export Issues: If there is an error while saving employee data or creating the ZIP file, a detailed error message will be displayed.

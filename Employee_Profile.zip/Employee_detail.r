# Define file paths
zip_file <- "C:/Users/akmusinguzi/Employee_Profile.zip"
output_folder <- "Employee Profile"

# Check if the ZIP file exists
if (!file.exists(zip_file)) {
  stop("ZIP file does not exist. Please check the file path.")
}

# Unzip the file
unzip(zip_file, exdir = output_folder)
files <- list.files(file.path(output_folder, "Employee Profile"), full.names = TRUE)
for (file in files){
  data <- read.csv(file)
  print(data)
}

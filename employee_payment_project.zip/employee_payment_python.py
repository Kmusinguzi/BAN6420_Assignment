import random
# create variable for dynamic worker generation
first_names = ["Alex", "Neriah", "Marvis", "Atarah", "Areille", "Zuri", "Shiloh", "Keith", "Max", "Aretha", "Kelvin", "Timothy"]
last_names = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Lopez", "Wilson", "Kenneth"]
gender = ["Male", "Female"]
role = ["Manager", "Engineer", "Analyst", "Estimator", "Architect"]

# generate list of 400 workers
employees = []
for i in range(1, 401):
       employee = {
           "ID": f"{i:003}",
           "Name": f"{random.choice(first_names)} {random.choice(last_names)}",
           "Gender": random.choice(gender),
           "Role": random.choice(role),
           "Salary": round(random.uniform(6000, 30000))
        }
       employees.append(employee)

for employee in employees:
       # assign employee level
       if 10000 < employee["Salary"] < 20000:
              employee["Level"] = "A1"
       elif 7500 < employee["Salary"] < 30000 and employee["Gender"] == "Female":
             employee["Level"] = "A5-F"
       else:
             employee["Level"] = "General"
       # generate payslip
       payment_slip = f"""
       payment_slip
       ID : {employee["ID"]}
       Name : {employee["Name"]}
       Gender : {employee["Gender"]}
       Role : {employee["Role"]}
       Salary : {employee["Salary"]}
       Level : {employee["Level"]}
       """
       print(payment_slip)

try:
    print(payment_slip)
except FileNotFoundError as e:
       print(e)
finally:
      print("Execution Completed")
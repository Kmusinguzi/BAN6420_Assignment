# Generation of Employee Payment Slips

This repository includes scripts for generating payment slips for 400 employees, featuring dynamically assigned salaries and job levels. The implementation is available in both Python and R.

## Python Script
- The `employee_payment_python.py` script generates 400 workers with random salaries and gender and assigns employee levels based on certain conditions.
- It handles exceptions and prints payment slips for each worker.

## R Script
- The `employee_payment_r.R` script performs the same operations as the Python script but is written in R.

## How to Run
### Python:
1. Ensure you have Python installed.
2. Run the following command:
   ```bash
   python employee_payment_python.py

### R:
1. Ensure you have R installed.
2. Run the following command:
   source('employee_payment_r.R')
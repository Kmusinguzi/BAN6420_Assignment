# Set number of employees
num_employees <- 400

# Define data
first_name <- c("Alex", "Neriah", "Marvis", "Atarah", "Arielle", "Zuri", "Shiloh", "Keith", "Max", "Aretha", "Kelvin", "Timothy")
last_name <- c("Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Lopez", "Wilson", "Kenneth")
gender <- c("Male", "Female")
roles <- c("Manager", "Engineer", "Analyst", "Estimator", "Architect")

# Generate data for employees
set.seed(123)
workers <- data.frame(
   first_name = sample(first_name, num_employees, replace = TRUE),
   last_name = sample(last_name, num_employees, replace = TRUE),
   gender = sample(gender, num_employees, replace = TRUE),
   roles = sample(roles, num_employees, replace = TRUE),
   salary = round(runif(num_employees, min = 6000, max = 30000))
)
 
# Generate employee levels and payment_slips
payment_slips <- data.frame(
 EmployeeID = 1:num_employees,
 FirstName = workers$first_name,
 LastName = workers$last_name,
 Gender = workers$gender,
 Role = workers$roles,
 Salary = workers$salary,
 EmployeeLevel = NA
)
 
# Loop through each worker and assign employee level
for (i in 1:num_employees) {
  tryCatch({
    if (payment_slips$Salary[i] > 10000 & payment_slips$Salary[i] < 20000) {
      payment_slips$EmployeeLevel[i] <- "A1"
    } else if (payment_slips$Salary[i] > 7500 & payment_slips$Salary[i] < 30000 & payment_slips$Gender[i] == "Female") {
      payment_slips$EmployeeLevel[i] <- "A5-F"
    } else {
      payment_slips$EmployeeLevel[i] <- "General"
    }
  }, error = function(e) {
    cat("Error occures at index", i, ": ", e$message)
    payment_slips$EmployeeLevel[i] <- "Error"
  })
 }
 
# Print the payment_slips data frame
print(payment_slips)
